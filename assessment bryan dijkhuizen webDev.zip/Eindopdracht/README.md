# A-special-day-wishlist
Dit is een project voor het fictieve bedrijf 'a-special-day'. 
Het bedrijf wilde een webapplicatie voor stellen die willen trouwen en zo hun wensenlijst kunnen publiceren aan de gasten.
Het bijzondere aan deze webapplicatie is dat de gasten kunnen aangeven welk item ze gaan kopen maar de stellen in kwestie kunnen dit uiteraard niet zien.

## Installation
```bash
git clone https://github.com/bryandijkhuizen/A-special-day-wishlist
```
## Usage
```php
import mysql database from the db_model folder
```
